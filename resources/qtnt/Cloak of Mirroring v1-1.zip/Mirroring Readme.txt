Cloak of Mirroring Fixpack v.1.1

  This pack fixes the infamous shimmering sphere animation overlay displayed by the Cloak of Mirroring in Baldur's Gate II expansion, Throne of Bhaal, as well as to take care of some related visual and audio effects. This pack won't make the Cloak reflect spells as it did in SoA, (to do it, simply move clck26.itm from your override folder). DON'T use the pack without ToB installed!  The pack was tested with second ToB beta patch and ToB final patch, (game versions 26464 and 26498, respectively), but things might yet change as new patches come out. It consists of the following files:

- CLCK26.ITM.TOB - the original ToB Cloak
- CLCK26.ITM.DISK - Cloak with SoA style of animation (disk at feet)
- clck26.itm.noanim - Cloak displaying no animation
- spmagglo.bam - No 'whiffle ball' fix
- spturni2.bam - No  disk fix
- aft_m10.wav - Sphere humming fix
- aft_m11.wav - Disk humming fix
- Mirroring Readme.txt - this file

  This is a workaround fix, which at the time has minor side effects. Bioware had animation hard-coded into the Cloak's new effect, so it can't be removed straight away at no cost. The technique we used prevents the game from displaying ANY animations hard-coded into effects, such as in Spell Trap (THAT darn globe) or Physical Mirror (disk at feet). SoA style fix won't nullify Physical Mirror visual effect as it displays the same animation. Neither file prevents effects from (Minor) Globe of Invulnerability, Globe of Blades, or Protection from Normal Missiles, for example. We are now working on a fix in which the Cloak won't prevent spells and items with spell-like effects from correctly displaying their respective animations. To hasten the process please report any interference the fixed Cloak causes to e-mail addresses found below.
  To use the Cloak fix, rename the file you want to clck26.itm and put it in your ToB override folder while the game is not running. Use clck26.itm.ToB to restore your game to the state it was in before fixing.
 Alternatively, you may use spmagglo.bam and spturni2.bam to totally prevent the game from displaying sphere and disk animations, respectively. Put these empty, zero-length file(s) into override folder and enjoy.
 The pack also includes a workaround for the "humming" effect played when the Cloak is on that some people complained about. First, you may try to adjust sound effects volume. If you prefer a harsher method, put the empty, zero-length file(s) aft_m10.wav and aft_m11.wav for ambients for sphere and disk, respectively, into override folder. As the sounds are hard-coded into the effects, too, you will experience loss of these sounds throughout the game.
 To undo the "empty file" fixes, delete the respetive file(s) from override, or restore the original one(s), if any.
 Credits: Sabre KE_sabre@hotmail.com (the original idea on how to stop that animation), Malbeth stoyanov@postman.ru (trappings, disk animation, empty file fixes).

  This and other BGII fixes are available from Sabre's site http://www.users.bigpond.com/qtnt/index.htm