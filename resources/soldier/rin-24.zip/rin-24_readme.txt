This item can be ased with all BG games

This Ring is a must have for any magic user
this ring is based on Trix's Staffs
He gets all the credit
This ring give you cleric spells and magic spells
no matter what class you are you can use it
but no evil people


How to use TBG Files (after Unzipping with Winzip)
1.  You must have the Item Text Editor from TeamBG.
2.  Save all files somewhere easy to locate 
   (create a TBG folder in your Baldur's Gate directory, for instance)
3.  Run the Item Text Editor Program.
4.  Load the TBG file and reply yes to the questions asked (such as do you want to save).
5.  The item is now in your Overrides Folder.6.  
    Repeat step 4 for all items you downloaded.
From here there are two ways to get the item into the game  

1st Option - CLUA Console Create item
1. Open notepad.
2. Open Baldur.ini in your Baldur's Gate directory in Notepad
   or other text editor.
3. Under [Game Options] add the following:   Cheats=1
4. Then save the file and run the game.
5. In the game, hit Ctrl+Tab to bring up the console in which
   you type the cheats. Ctrl+Tab will also close this console.
   Type in the cheats exactly as they appear below and hit the
   [Enter] key to activate.

CLUAConsole:CreateItem("xxxxxx",#####) - where xxxxxx is the code for an item.
 - where ###### is a number from 0 to 65535.
    (Note that the #'s aren't in quotes.)
 - places the item in the first empty inventory slot starting with you lead character.

2nd Option - Character Control Program
1.  Now, get the Character Control program from TeamBG.
2.  Load the character you would like to have the custom item(s).
3.  In Character Control, go to the inventory editor. 
4. Go to an empty backpack slot and click add/edit. On the screen that pops up, click manual entry.**

5. Input the name of the item file, click ok.**
6. Repeat 10 and 11 for all the files you'd like to add.
7. Start Baldur's Gate and import that character and there you are! 
** you can also edit the BGitems.cc files found in the Character control folder.
  Instructions on how to do this is available on TeamBG's Site)
  (TeamBG's website offers support on how to use it's editors)

Have Fun and thanks to everybody at TeamBG and
at the Hex Board for all of the help and support.

E-Mail: dharlomeskeep@hotmail.com