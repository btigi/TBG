A Magical Pair of Guantlets -- SoulRune (c) ^^DOUFAS^^
------------------------------------------------------
this is a cursed item which lets the user:
- cast SoulRune Death innate ability (kills any target instantly) after every rest
- makes the user invulnerable to non-magical weapons

Created by ^^Doufas^^

E-mail: Doufas@Hotmail.com

NOTE: To make this item work you must not only move soulrun.itm to your 
Overides folder, but souldth.spl as well.

------------------------------------------------------
This is my first real major item. It is one of the coolest items around (well I think so!)
and especially good for killing those hacked characters in multiplayer games.

SPECIAL THANKS TO:
Graf Hohfels
Seroki
Suryiel
Without your help I never would have been able to do it thanks GUYS YOU ROCK!


How to use TBG Files (after Unzipping with Winzip)

1.  You must have the Item Text Editor from TeamBG.
2.  Save all files somewhere easy to locate 
    (create a TBG folder in your Baldur's Gate directory, for instance)
3.  Run the Item Text Editor Program.
4.  Load the TBG file and reply yes to the questions asked 
    (such as do you want to save).
5.  The item is now in your Overrides Folder.
6.  Repeat step 4 for all items you downloaded.
7.  Now, get the Character Control program from TeamBG.
8.  Load the character you would like to have the custom item(s).
9.  In Character Control, go to the inventory editor.
10  Go to an empty backpack slot and click add/edit. On the screen 
    that pops up, click manual entry.**
11. Input the name of the item file, click ok.**
12. Repeat 10 and 11 for all the files you'd like to add.
13. Start Baldur's Gate and iport that character and there you are!

** you can also edit the BGitems.cc files found in th Character 
   control folder. Instructions on how to do this is available on 
   TeamBG's Site. TeamBG's website offers support on how to use it's
   Editors.

Have Fun and thanks to everybody at TeamBG and
at the Hex Board for all of the help and support.

My website: www.geocities.com/TimesSquare/Cave/7605/bgmain.html

E-Mail: dharlomeskeep@hotmail.com