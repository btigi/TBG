Hello!,	
             This is Kenny from southpark, he has no
custom items, but does have his own soundset and
portrait.


                       Hope you like him!
		                     -Evil Bob


   	 P.S

He is a necromancer, but he has the paper doll of a theif
so that he has a hood.  Enjoy!.