This is a A Halberd of stunning, it is a Halberd +4 and when it 
makes a successful hit it stuns the opponent.

If you need any instructions on how to use this weapon go to the 
instructions page on my web site.

Simclass

If you want to use this or any other of the things on my web site for 
any other web sites can you please ask first, I will very likely 
say yes but they do take me time to make so I would to be asked first.
