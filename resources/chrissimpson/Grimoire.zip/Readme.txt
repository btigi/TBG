(Maximize this window to read properly)

The Grimoire of Arcane Knowledge (Updated Version)
New Spells for Baldur's Gate
Created by Nimrod
  Nimrod667@Worldnet.att.net
Feel free to E-mail me if you have questions, problems, comments or suggestions.

With the aid of:
 Everyone at TeamBG - I quite literally couldn't have done it without you.
  www.bgrealms.com/teamBG/index.html
 The AXE hex editor
  www.kahei.com
 Thallic's BMP2BAM Converter
  www.geocities.com/SiliconValley/7169/
  
(Did you ever think you would be learning ancient magic from a guy named Nimrod?)

----------
CHANGES IN THIS UPDATE

Cleaner looking icons - If you already have new spells installed you only need to copy the new .BAM files to your Overrides folder.

Added Anti-Magic Shell, Blight, Cause Disease, Daer'Ragh's Aura Clensing, Icebolt, Shapeshift Web Spider, Stoneskin, and Wizard Eye.

Added prayer candles for the cleric spells Champion's Strength and Chaotic Commands.

Deathspell no longer affects your party.  You will need to import the new spell file.

The mustard jelly form now has only a -3 AC bonus to crushing weapons, but takes 1/2 damage.  Copy the new Plyjelly.itm file to your Overrides folder.

Added a tutorial walkthrough to this Readme document.  It's the last section.
----------
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! IMPORTANT !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

READ THIS DOCUMENTATION VERY CAREFULLY!! These spells can have as many as 9 components and wrongly installing the files may cause lockups or crashes!!  If you have a printer you may wish to print this out for easy reference.

These files are free and designed solely to enhance your enjoyment of Baldur's Gate.  You may distribute them as you see fit, however I ask that you please keep all the files together and include this Readme document.  To my knowledge these are bug-free, but I can assume no reponsibility for system problems or what have you.  Not that I'm worried about it, but I have to state it for the record. 

On a final note - I have made every effort to remain loyal to true AD&D rules, however in the interest of balance and usability a few changes have been made.  So please do not send me E-mails saying "HEY DORK! XX IS A YY LEVEL SPELL THAT DOES ZZ DAMAGE! YOU SCREWED UP!"  Chances are I already knew that.

----------
REQUIRED SOFTWARE

In order to properly import these files into your game you will need the TeamBG Item Text Maker and the FULL INSTALL version of the TeamBG Character Editor.  Both utilities are available for download at the TeamBG site.

----------
Readme Contents:
  Step by step instructions
  Magical items
  Spell list
  Important notes
  Using the TeamBG Item Text Maker
  Using the TeamBG Character Editor
  Using the Cheat Console
  Brief spell discriptions
  Tutorial walkthrough for beginners

----------
SECTION A: STEP BY STEP INSTRUCTIONS

1) BACKUP YOUR SAVED GAME!  Once the spells are in your spellbook they are VERY difficult to remove!
2) Each spell folder has several files.  Section C is a list of all files and their type.
3) Import the spell file using the TeamBG Item Text Maker (See Section E).  The spell files are Sppr###.tbg, Spwi###.tbg, or Spin###.tbg. 

4) !!!IMPORTANT!!!  When the spell file is imported it will have the .itm file extension.  You MUST change the extension to .spl.  Right click on the file icon and select 'Rename', then type in the filename with the new extension.  Make sure you do not have the "Hide extensions for known file types" option checked in the Windows Folder Options.

5) Import the item file using the TeamBG Item Text Maker (See Section E).  The Item files are Cler###.tbg, Mage###.tbg, or Inat###.tbg.  These files remain in .itm format.
6) Place the icon files into the 'Overrides' folder in the main Baldur's Gate directory.
7) Place any additional files into the 'Overrides' folder.  Some files are in .tbg format and must be imported as above.
8) Load a game and use the cheat console to create the proper magical item so you may learn the new spell.  (See Sections B and G)
----------
SECTION B:  MAGICAL ITEMS

For each spell there is a magical item that will allow you to give it directly to your character or NPC with no need for further editing.  You must have Tales of the Sword Coast installed to use the items for cleric spells or innate abilities.  If you do not, you can get the new spells by using the TeamBG Character Editor.  

Mage spells have scrolls that work normally allowing you to write the spell to your mage book or cast directly from the scroll.

Cleric spells have special prayer candles that must be placed in a quick item slot and used from the main game screen.  
!WARNING!  The candles have the same chances for failure as mage scrolls based on intelligence.  If your cleric has a low score, try having him/her drink a potion of genius beforehand (the item code is 'Potn29').  There is no 'feedback' text, so when you use each candle, check your cleric scroll to see if the spell was written.  If not, create another and try again.

Innate abilities use potions that when drunk will give the character the ability to use that spell once per day.  Drinking the same potion again will allow him to cast it twice per day, and so forth.
!WARNING!  Having existing innate spells will very occasionally conflict with those normally gained during play.  Druid shapeshift abilites will overwrite any existing ones, and your main character might not gain new abilities through the dreams.  I've never had this particular problem, but I've heard that others have.

----------
SECTION C:  SPELL LIST

Spell File  = The name of the spell file.
Item File   = The companion magical item that will let you learn the spell.
Icon Files  = The icon files.
Other Files = Additional files that must be placed for the spell to work.
Spells marked with a *T* require Tales of the Sword Coast to be installed to work properly.

Spell Name and Level          Spell File       Item File       Icon Files        Other Files
----------
MAGE SPELLS

Anti-Magic Shell L6           Spwi607.tbg     Mage607.tbg     Spwi607b.bam           -
                                                              Spwi607c.bam

Daer'Ragh's Aura Clensing L4  Spwi472.tbg     Mage472.tbg     Spwi472b.bam           -
                                                              Spwi472c.bam
 
Death Spell L6                Spwi605.tbg     Mage605.tbg     Spwi605b.bam           -
                                                              Spwi605c.bam

Flesh to Stone L6             Spwi604.tbg     Mage604.tbg     Spwi604b.bam           -
                                                              Spwi604c.bam
  
Gate L7                       Spwi701.tbg     Mage701.tbg     Spwi701b.bam       Demon.bcs
                                                              Spwi701c.bam       Demon.cre
                                                                                 Dmnswd.itm
                                                                                 Dmnring.itm

Globe of Invulnerability L6   Spwi602.tbg     Mage602.tbg     Spwi602b.bam           -
                                                              Spwi602c.bam      

Icebolt L2                    Spwi291.tbg     Mage291.tbg     Spwi291b.bam           -
                                                              Spwi291c.bam

Ice Storm L4                  Spwi491.tbg     Mage491.tbg     Spwi491b.bam           -
                                                              Spwi491c.bam

Invisibility 10' Radius L3    Spwi393.tbg     Mage393.tbg     Spwi393b.bam           -
                                                              Spwi393c.bam

Invisible Stalker L6          Spwi601.tbg     Mage601.tbg     Spwi601b.bam           -
                                                              Spwi601c.bam

Melf's Explosive Meteors L5   Spwi591.tbg     Mage591.tbg     Spwi591b.bam       EMeteor.tbg
                                                              Spwi591c.bam       IMeteor.bam

Melf's Minute Meteors L3      Spwi391.tbg     Mage391.tbg     Spwi391b.bam       Meteor.tbg
                                                              Spwi391c.bam       IMeteor.bam

Ray of Frost L3               Spwi392.tbg     Mage392.tbg     Spwi392b.bam           -
                                                              Spwi392c.bam

Stone to Flesh L6             Spwi606.tbg     Mage606.tbg     Spwi606b.bam           -
                                                              Spwi606c.bam

Stoneskin L4                  Spwi473.tbg     Mage473.tbg     Spwi473b.bam           -
                                                              Spwi473c.bam

Tenser's Transformation L6    Spwi603.tbg     Mage603.tbg     Spwi603b.bam           -
                                                              Spwi603c.bam

Wizard Eye L4                 Spwi474.tbg     Mage474.tbg     Spwi474b.bam           -
                                                              Spwi474c.bam

Wraithform L3                 Spwi315.spl          -               -                 -
                                              

There is one more mage spell that is already in the game and works fine.  It is Cone of Cold and the item code for the scroll is 'Scrl2f'.
----------
CLERIC SPELLS

Aerial Servant L6             Sppr601.tbg     Cler601.tbg     Sppr601b.bam      Airsrv.bcs
                                                              Sppr601c.bam      Airsrv.cre
                                                                                Airswd.itm
                                                                                Airshl.itm
                                                                                Airhlm.itm

Armor of Darkness L3          Sppr393.tbg     Cler393.tbg     Sppr393b.bam      Shar.wav
                                                              Sppr393c.bam

Blight L1                     Sppr192.tbg     Cler192.tbg     Sppr192b.bam           -
                                                              Sppr192c.bam

Call Undead L5                Sppr593.tbg     Cler593.tbg     Sppr593b.bam           -
                                                              Sppr593c.bam

Cause Critical Wounds L5      Sppr591.tbg     Cler591.tbg     Sppr591b.bam           -
                                                              Sppr591c.bam

Cause Disease L4              Sppr492.tbg     Cler492.tbg     Sppr492b.bam           -
                                                              Sppr492c.bam

Cause Light Wounds L1         Sppr191.tbg     Cler191.tbg     Sppr191b.bam           -
                                                              Sppr191c.bam

Cause Serious Wounds L4       Sppr491.tbg     Cler491.tbg     Sppr491b.bam           -
                                                              Sppr491c.bam

Champion's Strength L5             -          Cler507.tbg          -                 -

Chaotic Commands L5                -          Cler508.tbg          -                 -


Feeblemind L6                 Sppr603.tbg     Cler603.tbg          -                 -

Flesh to Stone L6             Sppr604.tbg     Cler604.tbg     Sppr604b.bam           -
                                                              Sppr604c.bam

Harm L6                       Sppr606.tbg     Cler606.tbg     Sppr606b.bam           -
                                                              Sppr606c.bam

Heal L6                       Sppr605.tbg     Cler605.tbg     Sppr605b.bam           -
                                                              Sppr605c.bam

Hold Monster L6               Sppr602.tbg     Cler602.tbg          -                 -

Pain L3                       Sppr391.tbg     Cler391.tbg     Sppr391b.bam           -
                                                              Sppr391c.bam

Selune's Blade L3             Sppr392.tbg     Cler392.tbg     Sppr392b.bam      Selune.tbg
                                                              Sppr392c.bam

Selune's Blessing L5          Sppr592.tbg     Cler592.tbg     Sppr592b.bam           -
                                                              Sppr592c.bam

Selune's Curse L7             Sppr701.tbg     Cler701.tbg     Sppr701b.bam           -
                                                              Sppr701c.bam

Stone to Flesh L6             Sppr607.tbg     Cler607.tbg     Sppr607b.bam           -
                                                              Sppr607c.bam

Transport via Plants L5       Sppr594.spl     Cler594.spl     Sppr594.spl            -
                                                              Sppr594.spl

----------
INNATE SPELLS
  
Berserk                       Spin201.tbg     Inat201.tbg          -            Berserk.wav

Create Poisoned Arrows        Spin202.tbg     Inat202.tbg          -            Poisarow.tbg

Create Poisoned Bolts         Spin203.tbg     Inat203.tbg     Spin203b.bam      Poisbolt.tbg


To use any of these shapeshifting abilities you must also import Spin210.tbg, (Spin221.tbg and Spin222.tbg for the Web Spider) and change the file extention from .itm to .spl.  Otherwise you will not be able to change back.

Lycanthropy *T*               Spin218.tbg     Inat218.tbg     Spin218b.bam      Lycanth.cre
                                                                                Lycanth.itm
                                                                                Lycanth.wav
                                                                                Spin210.tbg

Shapeshift Black Bear *T*     Spin212.tbg     Inat212.tbg          -            Brblp.itm
                                                                                Spin210.tbg

Shapeshift Brown Bear *T*     Spin213.tbg     Inat213.tbg          -            Brbrp.itm
                                                                                Spin210.tbg
                                                                                
Shapeshift Flind *T*          Spin214.tbg     Inat214.tbg          -            Plyfist.itm
                                                                                Spin210.tbg

Shapeshift Mustard Jelly *T*  Spin217.tbg     Inat217.tbg          -            Plyjelly.itm
                                                                                Spin210.tbg

Shapeshift Ogre *T*           Spin215.tbg     Inat215.tbg          -            Plymstar.itm
                                                                                Spin210.tbg

Shapeshift Sword Spider *T*   Spin216.tbg     Inat216.tbg          -            Plyspid.itm
                                                                                Spin210.tbg

Shapeshift Web Spider *T*     Spin220.tbg     Inat220.tbg          -            Plyspid.itm
                                                                                Spin221.tbg
                                                                                Spin222.tbg
                                                                                Shar.wav

Shapeshift Wolf *T*           Spin211.tbg     Inat211.tbg          -            Wolfm.itm
                                                                                Spin210.tbg

  
----------
SECTION D:  IMPORTANT NOTES

Wraithform - This spell was already in the game, but did not work.  There is no need to import anything with this one, just place the new Spwi315.spl file into your Overrides folder.  The item code for the scroll is 'Scrl1r'.

Champion's Strength and Chaotic Commands - These spells were already in the game but only existed in scroll form.  The .itm files are prayer candles to allow your cleric to learn them.

Berserk Innate Ability - Includes an extra file 'Berserk.wav' that must be placed in the 'Overrides' folder.  This is the sound played when the spell is cast.  If you wish to personalize it, rename any .wav file (usual format for custom sounds - 16bit Mono) as Berserk.wav and place it in the 'Overrides' folder.  For example, you can make your character give his battle cry when he berserks by making a copy of the first sound in your voice set and renaming it 'Berserk.wav'.

Shapeshift Innate Abilities - These spells do NOT work well with the Druid shapeshift abilities. They have their own 'Shapeshift Natural Form' and changing back with the Druid version may cause problems.  The included .itm files are improved creature weapons for shapeshifting.  These are optional, but greatly increase the usefulness of these abilities.  You must have the Full Install of Tales of the Sword Coast to use Lycanthropy or the Innate Shapeshifting abilities.

Shapeshift Web Spider - Due to the additional abilities gained this spell uses its own 'return to natural form' and therefore works best without any other shapeshift abilities.  You must place the Plyspid.itm file into your Overrides folder to be immune to your own webs.

----------
SECTION E:  USING THE TEAMBG ITEM TEXT MAKER

1) At the top of the window click 'File' then 'Import Item and Text'. 
2) Select the .tbg file you want to import and click 'Open'.
3) When asked if you want to save the item click 'yes' and the file will be placed directly into your Overrides folder in .itm format. 

----------
SECTION F:  USING THE TEAMBG CHARACTER EDITOR

If you do not have Tales of the Sword Coast installed the items for cleric spells and innate abilities will not work and you will have to use the TeamBG character editor. 
1) Export the character you want to give the spells to. 
2) Run the TeamBG Character Editor and open the exported file.  
3) Select the 'Known Spells' section and highlight a spell you don't use.  
4) Click 'Change', check the 'Manual Entry' box, and type in the name of the spell file.
5) Select the proper type (Cleric or Special) and the proper spell level, then click 'Select'.
6) Save the character and then load your game (You must be in multiplayer mode - details on this are in the Character Editor Help file).
7) When the character arbitration screen comes up, delete the old version of your character and import the new one.  

---------
SECTION G:  USING THE CHEAT CONSOLE

1)  Locate the Baldur.ini file in the main Baldur's Gate directory.
2)  Open it with Notepad, and under the "Game Options" section insert the line (case sensitive):

Cheats=1

3)  Save the file.
4)  Load a game, and while in the main game screen press Ctrl+Tab.  This will open a small input console at the bottom of the screen.  Pressing Ctrl+Tab again will close it.
5)  Type the following command (cAse sENsitIvE) and press enter:

CLUAConsole:CreateItem("XXXXXXXX")

where XXXXXXXX is the filename of the item you wish to create.  Example:

     CLUAConsole:CreateItem("Mage601")
     Creates the Invisible Stalker mage scroll

The item will be created in the first available inventory slot in your party.

----------
SECTION H:  BRIEF SPELL DESCRIPTIONS

Mage
----
Anti-Magic Shell - Blocks all magic and spell effects
Daer'ragh's Aura Cleansing - Allows faster spellcasting
Death Spell - Kills multiple enemies
Flesh to Stone - Petrifies an enemy
Gate - Summons a lesser demon
Globe of Invulnerability - Protects against 1st - 4th level spells
Icebolt - Bolt of ice causing 2d10 damage
Ice Storm - Causes cold damage every round over a 25' area
Invisiblity 10' Radius - Multiple characters become invisible
Invisible Stalker - Summons an invisible stalker
Melf's Explosive Meteors - Creates thrown missiles that explode on contact
Melf's Minute Meteors - Creates thrown missiles that cause fire damage
Ray of Frost - 5d6 damage on one enemy and possible slowing
Stone to Flesh - Cures petrification
Stoneskin - Reduces damage from physical attacks
Tenser's Transformation - Boosts attributes and combat abilities
Wizard Eye - Like Clairvoyance but works anywhere
Wraithform - Caster becomes ethereal and invulnerable to normal weapons

Cleric
------
Aerial Servant - Summons an aerial servant
Armor of Darkness - Creates black shadowy armor
Blight - Reduces THAC0 and morale of hostile creatures
Call Undead - Summons ghouls and ghasts
Cause Critical Wounds - Causes 27 points of damage
Cause Disease - Diseases target with varied effects
Cause Light Wounds - Causes 1-8 points of damage
Cause Serious Wounds - Causes 17 points of damage
Champion's Strength - Strength and THAC0 bonus
Chaotic Commands - Immunity to mind affecting spells
Feeblemind - Reduces intelligence of target
Flesh to Stone - Petrifies an enemy
Harm - Kills instantly or causes 4d8 damage
Heal - Heals massive wounds and cures poison and paralysis
Hold Monster - Paralyzes 1-4 creatures of any type
Pain - Combat penalties to multiple enemies
Selune's Blade - Creates a powerful flaming sword
Selune's Blessing - Drops armor class and protects from 1st-4th level spells
Selune's Curse - Ice explosion causing 10d10 damage
Stone to Flesh - Cures petrification
Transport via Plants - Teleportation

Innate
------
Berserk - Combat bonuses and immunity to fear
Create Poisoned Arrows - Creates poison arrows (non-Eldoth only)
Create Poisoned Bolts - As above but creates quarrels
Lycanthropy - Shapeshift werewolf - has immunity to non magical weapons, but may berserk
Shapeshift Web Spider - A spider form that can cast webs
Other Shapeshifts - As the polymorph spell, new weapons give better to hit rolls and armor class, spider now poisons and is immune to webs, mustard jelly is resistant to blunt weapons and causes poison and slowing, weapons also work with the Polymorph spell and Druid abilities

----------
SECTION I:  TUTORIAL WALKTHROUGH FOR BEGINNERS

We'll install one of the simpler spells, Icebolt.

1) Check to make sure all the files listed in the Spell List above are in the Icebolt folder.  There should be four files: Spwi291.tbg, Mage291.tbg, Spwi291b.bam, and Spwi291c.bam.
2) Start up the TeamBG Item Text Maker and select the 'Import Item and Text' option from the File menu.
3) Locate the Icebolt folder and highlight Spwi291.tbg, then click 'Open'.  When it asks if you want to save this item, click 'Yes'.  Repeat this process to import Mage291.tbg.
4) Both files will now be in your Overrides folder in .itm format.  Exit the Item Text Maker, then open your Override folder and locate Spwi291.itm.
5) Right click on the file icon and select 'Rename'.  Type in Spwi291.spl and hit Enter.  Do not rename Mage291.itm, it is fine the way it is.  Leave both files in the Override Folder.
6) Copy Spwi291b.bam and Spwi291c.bam from the Icebolt folder to the Override folder.
7) Load a saved game and use the Cheat Console to create the item Mage291 (see Section G).  This will create the mage scroll that you may use to either cast the spell or write it to your spellbook.
