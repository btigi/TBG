Thanks for downloading this soundset that I made, it was made from the Farm sounds from Warcraft2,
It is unique, give it a go I am sure you will enjoy it.

Visit Simclass's Web Site (very cool):

(Baldur's Gate Storeroom): www.btinternet.com/~Chris_Simpson1/Main.htm

You can e-mail me at:

doomlord2@hotmail.com

Or Simclass at:

Chris_Simpson1@btinternet.com

Doomlord

P.S   Have fun.