Powerword, Kill - 9th Level Mage Spell
----------------------------------

This zip file contains the following items:

SWCU900a.bam
SWCU900b.bam
SWCU900c.bam
SWCU900-s.tbg - The Spell


Place the .BAM files in the Override folder.
Import the .TBG files using the TeamBG SpellMaker.
Make a scroll to learn the spell with TeamBG SpellMaker.

Use the CLUA command to import the Scroll into the game!

Enjoy,
CuChoinneach
