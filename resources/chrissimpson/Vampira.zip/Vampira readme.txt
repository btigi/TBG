Vampire character file
----------------------------------

This zip file contains the following items:

tge_110L.bmp
tge_110s.bmp
Vampira.chr
SPIN709-s.tbg
SPIN710-s.tbg
coffin.itm
VPclck.itm
vamprng.itm
vamp.bcs

Place the tge_110L.bmp and tge_110s.bmp in your Portraits folder.
Place the Vampira.chr file in your Character folder.
Import SPIN709-s.tbg & SPIN710-s.tbg
using the TeamBG SpellEditor.
Place all the .itm files and the .bcs file in the overrides folder.

Now when you want to start a new game or add to a multiplayer game, just import the Vampira file.
I would suggest using a custom sound file (don't have one, don't ask)
I use Safana's sounds...they just seem to work (She's such a vamp anyway!!)

This is a true to rules Vampire...she uses no weapons and can't use them. All her damage is by touch.
She has life steal, energy drain and removes 2 Experience Levels from victim. She is undead and can be
turned by a Priest or high level Paladin.

There are not any discriptions with her items because they are not necessary. If you remove her cloak
you will be removing her life force and she will be a very weak, stupid easy target. I suggest never
remove curse and remove her cloak. She is a very simple example of what can be done with a custom
character file.

I will not be releasing any new items until Roach and I finish our project!...You will be very happy
to see what we are creating...but no hints now! I only released this one since there is such an interest in Vampire PCs
Now!

Enjoy,
CuChoinneach
