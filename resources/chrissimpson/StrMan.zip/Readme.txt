This is a A Strong Man's Sword, it is a 2-handed sword +3 +1
constitution and stength.

If you need any instructions on how to use this weapon go to the 
instructions page on my web site.

Simclass

If you want to use this or any other of the things on my web site for 
any other web sites can you please ask first, I will very likely 
say yes but they do take me time to make so I would to be asked first.
