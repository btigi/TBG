This readme is for my Cloud character pack. He is the main character in 
Final Fantasy 7.

This character pack comes with a character, portraits, his best weapon 
with his final Limit Break, and the Tetra Elemental.

Cloud.chr     -  put in the Characters folder
CloudL.bmp    -  put in Portraits folder
CloudS.bmp    -  put in portraits folder
Ultima.tbg    -  open with the item text editor & put in the override folder
Ultima.bam    -  put in override folder
simm101-s.tbg -  open with the spell editor or open with the text editor and 
                 change the ending from .itm to .spl
simm101.bam   -  put in override folder
tetra.tbg     -  open with text editor & save to override folder

the simm101-s.tbg is the Limit Break. it is an innate ability.

you don't have to change the color of Cloud's clothes & hair. i did that for
you. just make sure his skin is white if you want it exactly like it is in 
FF7.

please don't email me saying that the tetra elemental doesn't give you hp 
against poison like in FF7. it is extremely hard to do that so i didn't since
these are my first item's & spells i have made.

please don't email me saying that the Ultima weapon isn't pink & purple 
because it is in the playstation game. It isn't in the PC version. I thought 
it would make you stand out with the brighter colors so i did.

i will make the rest of the FF7 character except Cait Sith.

if you have any questions, comments, constructize criticism, problems or 
anything email me
mjf73086@aol.com

thanx,
M 