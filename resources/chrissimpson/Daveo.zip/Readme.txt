This is Daveo's sound set, just take the sound files and put them
into the sound directory in the Baldurs Gate folder. I am unsure 
of what his proper name is, if you know can you please e-mail it to me.
This set is perfect for evil magesof any race.

This set was made by Simclass, I hold no responsibility for any damage
caused by them. I allow you to distribute this as much as you want as
long as you make sure my name is mentioned.