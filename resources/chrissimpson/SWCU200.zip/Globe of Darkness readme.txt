Globe of Darkness - 2nd Level Mage Spell
----------------------------------

This zip file contains the following items:

SWCU200a.bam
SWCU200b.bam
SWCU200c.bam
SWCU200-s.tbg - The Spell



Place the .BAM files in the Override folder.
Import SWCU200-s.tbg using the TeamBG SpellMaker.
Make a scroll to learn the spell with TeamBG SpellMaker.

Use the CLUA command to import the Scroll into the game!

Enjoy,
CuChoinneach
