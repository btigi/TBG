Note: all this wouldnt have ever been possible without the help of TeamBG's work and time.

Files included with .zip

Readme.txt-File your reading right now
Grenammo.TBG-item that goes into your bolt/arrow/bullet slot.
Gren.tbg-item that goes into your weapon slot.
Iexpl.bam-custom .bam file made by Andy
Spwix1-spell file for the item
Spwix2-spell file for the item
Spwix3-spell file for the item

To use this:
1.  Place all the .spWix's and the Iexpl.bam into the overrides

2.  Import the .tbg's with TeamBG's Item Text Editor.

4.  Use either the CLUAConsole:CreateItem("xxxxx") cheat or the TeamBG character editor to import the item into your game.

5.  Enjoy!

Another Note:

Remember, IT'S A GRENADE!! If your character is in the area of effect 
it will get you too! the spells cannot be put into a spellbook, they are 
just for the grenade. If you modify the file, then it can be.But you will have to do that yourself.

This item was made by Banelord Give him full credit.