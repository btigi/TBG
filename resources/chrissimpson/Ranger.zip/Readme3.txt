Thanks for downloading this soundset that I made, it was made from the Ranger sounds from Warcraft2,
 I think it could be used for a Ranger or a Paladin, but definitely a Good character, probably Lawful:

Visit Simclass's Web Site (very cool):

(Baldur's Gate Storeroom): www.btinternet.com/~Chris_Simpson1/Main.htm

You can e-mail me at:

doomlord2@hotmail.com

Or Simclass at:

Chris_Simpson1@btinternet.com

Doomlord

P.S   Have fun.