                           Baldur's Gate(tm)

              Drizzt Do'Urden Unofficial Addon Beta 0.1
			    
			    March 1999
	
Contents:

x.	Disclaimer

	a.	Preparing Baldur's Gate (tm)

1.	GETTING STARTED

	a.	Files included within the ZIP
	b.	Installing the files
	c.	Selecting Drizzt within the game
		
		1. SINGLE PLAYER
		2. MULTI PLAYER

2.	GAME BALANCE AND DRIZZT

	a.	Minor inconsistencies with Drizzt
	b.	Why use Drizzt??
	c.	Some fianl words on Drizzt Do'Urden
		

3.	SPECIAL THANKS & ACKNOWLEDGEMENTS
=======================================================================

X. DISCLAIMER

This is an unofficial addon to Baldur's Gate that I took the time to 
create to use as a support character in a multi player environment. I 
take no responsibility for any crashes, loss of data, performance 
issues or general malfunctions or otherwise of any computer that 
occurs as a result of using, modifying, installing or any other means
of rendering a computer vulnerable to the data contained in these 
files.
Baldur's Gate(tm) remains a registered trademark by Black Isle Studios 
and Interplay Ltd. These files are in no way affiliated with these two
companies.


a.	PREPARING BALDUR'S GATE(tm)


Firstly, you may be required to download and install the 1.1.4315
patch for the game. The reason that I ask you to do this is because
the character Drizzt I created was on a computer that already had the 
patch installed. If the patch hasn't been installed, I cannot be sure 
that the game will work properly with Drizzt. Once this is done please 
create the following sub-directories in the \BALDUR'S GATE directory. 
(If any of these dirs are already present please skip and move onto
the next one.)

dirs:	CHARACTERS
	SOUNDS
	PORTRAITS

Finished that?? You're now ready to start!

1.	GETTING STARTED.

a.	Files included within the ZIP.

	DRIZZT.CHR
	README.TXT (This file)
	DRIZZTA.WAV
	DRIZZTB.WAV
	DRIZZTC.WAV
	DRIZZTD.WAV
	DRIZZTE.WAV
	DRIZZTF.WAV
	DRIZZTG.WAV
	DRIZZTH.WAV
	DRIZZTI.WAV
	DRIZZTJ.WAV
	DRIZZTK.WAV
	DRIZZTL.WAV
	DRIZZTM.WAV
	DARKELFL.BMP
	DARKELFS.BMP


b.	Installing the files


Open the .ZIP file and extract into the \BALDUR'S GATE (or whatever
directory Baldur's Gate is in) directory. I have attempted to recurse
the directories in the ZIP so the the .CHR .WAV and .BMP files should
go into their respective places. If not, UNZIP all the files to a TEMP
directory and cut and paste all the .CHR files into \CHARACTERS, 
.WAV files into \SOUNDS and .BMP files into \PORTRAITS.

Once this is done you are ready to start the game!

	

c.	Selecting Drizzt within the game


SINGLE PLAYER:-

1. Start a NEW game

2. Select the IMPORT button

3. Select 'DRIZZT'

4. Select 'DONE'

5. Select 

6. Adjust Drizzt's hair to white, skin to black and clothing to
   dark Blue

6. Click 'DONE'

7. Select 'Drizzt' in the Sounds menu

8. Select 'DONE'

9. Select 'NAME'

10. Enter "Drizzt Do'Urden"

11. Select 'DONE'

NOTE: You might find that the portrait doesn't display properly, if
it doesn't all you have to do is select 'CUSTOMIZE' within the game,
at the character statistics menu. The portrait that Drizzt uses is 
darkelfl.BMP and darkelfs.BMP. Once these are re-selected the picture
should come up.

MULTI-PLAYER:-

Drizzt can be added to an existing party, provided there is one space 
available. Just select the spare space, select 'CREATE' and IMPORT as
in the single player game. This also applies if a new multi player game
is being started. 

NOTE:- Besides paying heed to the other note above, if you are playing
over the 'net or on a LAN, please ensure that all the other computers
have copies of the above files on their computers, otherwise your
portrait will not appear on their computer, nor will the sounds be
heard. (This is a common sense thing; if you are using ANY unique
portrait or sound, the other computers MUST have a similar copy.
BTW, make sure that everybody has the 1.1.4315 patch installed...)


2.	GAME BALANCE AND DRIZZT

a.	Minor Inconsistencies with Drizzt


Alas, there are some who will balk at the fact that Drizzt is 1st
Level, as opposed to a 16th level Ranger and a 18th Level Fighter. 
He can only use one Scimitar at a time and Guenhwyvar is nowhere to 
be found. To make up for these shortfalls, I have given him the 
following items and abilities:

4 weapon proficiencies for Large Sword
Gauntlets of Weapon Mastery
Boots of Speed.
Augmented Hide in Shadows

This is in addition to the following items:

Scimitar +3, Frostbrand
Scimitar +5, Defender
Mithril Chainmail +4.

Drizzt also has the following statistics:

STR: 13
DEX: 20
CON: 15
INT: 17
WIS: 17
CHA :14

The solo scimitar weapon display and the lack of the 'black cat' is
something that couldn't be adjusted, ie: they are not supported within
the game. Why 1st level?? Well, there are many reasons, primarily:
What is the point of having a 16th level Ranger running around with 1st
to 7th level characters?? There is no point and besides,there is no 
character development for poor old Drizzt, I will guarantee that you 
would get sick of the game within the first hour.
In playtesting, I have found that he has been a good balanced support
character for a small party. (There have been times that I have feared 
for his life) and if role-played correctly, (send him out ahead as a 
scout) is a fine addition to any party without overbalancing the game.

	
b.	Why use Drizzt??


I have intended that Drizzt be used as a support character in a multi-
player game in Baldur's Gate. The whole idea was sparked by the cameo
appearance of the stoic ranger during my first run at the game.
Initially, I was unsatisfied with the choice of NPCs that the single
player side of the game offered, so I restarted the game after finish-
ing it. This time around, however I selected the multiplayer option and
imported some of the items I had found the first time around (Boots of
Speed and Gauntlets of Weapon Mastery) and I even managed to generate
the 96 character statistic points necessary for the Ranger (the only
difference was 19 DEX and 15 CHA) This was altered with the use of the
BALDUR'S GATE Game Editor (Gatekeeper) Created by Arron O'Neil (See 
3. Below) Drizzt's weapons and armour were also generated with the use
of Gatekeeper. The sounds are taken from the original Drizzt within 
the game with the use of BIFEdit by Daniel Lemburg (as a point of 
interest, Daniel, if you are reading this Drizzt's Sounds are 
UNKNOWN280 to 287 inclusive in the NPCsounds.BIF file) Getting back to
the sounds, You will notice that there are only 13 sound files for 
Drizzt - in reality, there are only 8 - I doubled up on five of them. 
If anyone can manage to either come up with a DECENT set of 23 sound 
files for Drizzt or make another ten to fifteen phrases that sound 
similar to the ones in the game, please email me.


c.	Some final words of Drizzt Do'Urden


Drizzt Do'Urden is a renegade Drow Elf Fighter turned Ranger of 
House Daermon N'a'shezbaernon, once the Ninth House of Menzoberranzan.
Having trained under Zaknafien Do'Urden (his father) and then Mooshie
the Ranger, Drizzt has gone on to become a somewhat (in)famous
personality throughout the Realms and the Lower Planes. Needless to 
say that he is (or will be) VERY good at fighting. As I've stated many
times througout this file, he is very good as a SUPPORT character and 
is ideal for MULTIPLAYER use. If you feel that he is overbalancing your
game, DON'T USE HIM! Because I treat him as an NPC in may party, I feel
justified for having cheated slightly, although 80% of Drizzt's makeup 
has been hard won through diligent gameplay by the characters that 
came before him. Remember that he is only 1st level and has still a 
long way to go before reaching his peak of 7th in Baldur's Gate. 



3.	SPECIAL THANKS AND ACKNOWLEDGEMENTS

I would like to thank the following people:

Aaron O'Neil for the creation of Gatekeeper(tm). Aaron can be reached
on bg@mud-master.com

Daniel Lemburg for the creation of BIFEdit(tm). Daniel can be reached
on lemburg@home.com

R.A. Salvatore for the writing of the Crystal Shard and all the 
subsequent books that has featured so many colourful characters, 
especially Drizzt Do'Urden.

To that Larry Elmore, for doing such a good job on the first picture of 
Drizzt.

To BGDungeon, in advance for use of their resources.  

http://forsite.net/soc/gate/


To anyone that I have sent this .ZIP file to, thanks for putting
it on your webpage.

If I have missed anybody, I am truly sorry.


I can be reached on the following email address:

ptohotep@hotmail.com

Any constructive comments or suggestions are welcome. I am still
looking for a way to change the normal player sprite to that of 
Drizzt. If anyone has an idea, let me know. Anyway enjoy!

Andy Gale :o)