This is Kagain's sound set, just take the sound files and put them
into the sound directory in the Baldurs Gate folder.
This set is perfect for evil Dwarves, Gnomes and Halflings.

This set was made by Simclass, I hold no responsibility for any damage
caused by them. I allow you to distribute this as much as you want as
long as you make sure my name is mentioned.