This is Drizzt's sound set, just take the sound files and put them
into the sound directory in the Baldurs Gate folder.
This set is perfect for people who,.....well want to play as Drizzt.

This set was made by Simclass, I hold no responsibility for any damage
caused by them. I allow you to distribute this as much as you want as
long as you make sure my name is mentioned.