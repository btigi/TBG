Prismatic Spray - 7th Level Mage Spell
----------------------------------

This zip file contains the following items:

SWCU700a.bam
SWCU700b.bam
SWCU700c.bam
SWCU700-s.tbg - The Spell
PSblue-s.tbg
PSgreen-s.tbg
PSindigo-s.tbg
PSorange-s.tbg
PSred-s.tbg
PSviolet-s.tbg
PSyello-s.tbg


Place the .BAM files in the Override folder.
Import all .TBG files using the TeamBG SpellMaker.
Make a scroll to learn the spell with TeamBG SpellMaker.

Use the CLUA command to import the Scroll into the game!

Enjoy,
CuChoinneach
