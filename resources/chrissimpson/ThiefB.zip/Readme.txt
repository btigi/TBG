This is Thieves Blade, a short sword 1d6+4 +2 poison for 30 seconds. 
It gives +1 Dexterity and +15 on all thieving skills.

If you need any instructions on how to use this weapon go to the 
instructions page on my web site.

Simclass

If you want to use this or any other of the things on my web site for 
any other web sites can you please ask first, I will very likely 
say yes but they do take me time to make so I would to be asked first.
