The sounds you have just downloaded were compiled by Ajoc1.

To use these sounds, copy and paste them all into your "sounds" folder and choose the set when you create a new character.

Thanks goes to Grog who taught me how to create the soundsets, and TeamBG for the wonderful tools they've brought us.

If you want to contact me:

mbtq86@ukgateway.net

My site is at:

http://www.crosswinds.net/~ajoc1/bgtreasury/BGtreasury.htm

thanks for downloading these files!:)