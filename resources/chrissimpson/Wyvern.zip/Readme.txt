This is a Wyvern's sound set, just take the sound files and put them
into the sound directory in the Baldurs Gate folder.
This is perfect for people who,.....well just want a change, something
different, very different.

This set was made by Simclass, I hold no responsibility for any damage
caused by them. I allow you to distribute this as much as you want as
long as you make sure my name is mentioned.