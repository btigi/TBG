This is Bilbo from the Lord of The Rings and has a number of custom
 items and has it's own portraits. 

If you need any instructions on how to use this character go to the 
instructions page on my web site.

Bilbo.chr - The actual character
Bildag.tbg - Bilbo's Dagger
Bilbow.tbg - Bilbo's Fire Bow
Bilarm.tbg - Bilbo's Armour
Gollum - Gollem's/Bilbo's ring
BilboL.bmp - Large Portrait
BilboS.bmp - Small Portrait

If you want to use this or any other of the things on my web site for 
any other web sites can you please ask first, I will very likely 
say yes but they do take me time to make so I would like to be asked first.

If you have any comments or queries about this set or any other part of my site 
please contact me at:
Chris_Simpson1@btinternet.com

Have Fun

Simclass
