This is Golems ring is from the Lord of The Rings and gives the wearer 
invisibility, it also affects the wearers health though.

If you need any instructions on how to use this weapon go to the 
instructions page on my web site.

Simclass

If you want to use this or any other of the things on my web site for 
any other web sites can you please ask first, I will very likely 
say yes but they do take me time to make so I would to be asked first.
