Thank you for downloading this and any other item that you download of mine.  

Visit my site Baldur's Gate Storeroom:

www.btinternet.com/~chris_simpson1/Main.htm

And you can e-mail me:

Chris_Simpson1@btinternet.com

Simclass