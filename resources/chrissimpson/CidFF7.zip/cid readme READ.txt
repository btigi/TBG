This readme is for my Cid character pack. He is a character in 
Final Fantasy 7.

This character pack comes with a character, portraits, his best weapon 
with his final Limit Break, and the Tetra Elemental.

Cid.chr     -  put in the Characters folder
CidL.bmp    -  put in Portraits folder
CidS.bmp    -  put in portraits folder
VenusG.tbg    -  open with the item text editor & put in the override folder
IVenusG.bam    -  put in override folder
simm102-s.tbg -  open with the spell editor or open with the text editor and 
                 change the ending from .itm to .spl
simm102.bam   -  put in override folder
tetra.tbg     -  open with text editor & save to override folder

the simm101-s.tbg is the Limit Break. it is an innate ability.

you don't have to change the color of Cid's clothes & hair. i did that for
you. just make sure his skin is white if you want it exactly like it is in 
FF7.

i will make the rest of the FF7 character except Cait Sith.

if you have any questions, comments, constructize criticism, problems or 
anything email me
mjf73086@aol.com

thanx,
M 