This  is the Phantom Sword. It gives user haste, sanctuary, increased spell casting speed, increased speed,
 infravision, and immunity all spells (1-9).  When it hits the target it gives them poison, panic, sleep, 2d2 fire
damage, and casts magic missile.

Made By Eventine

----------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------

Visit Simclass's Web Site:

(Baldur's Gate Storeroom): www.btinternet.com/~Chris_Simpson1/Main.htm

You Can E-Mail Simclass at:

Chris_Simpson1@btinternet.com
