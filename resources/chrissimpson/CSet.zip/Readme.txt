This is a character set made by Simclass, there is a set of normal
characters with custom portraits. They all have items which you can
buy during the course of the game. They are not overkill weapons, they
are just slightly better weapons to enhanse the game. There are 7 
characters, Rand, Mat, Perrin, Lan, Moiraine, Egwene and Elayne. The 
first 6 can be imported into the game towards the start (as they all
have 0 xp), but Elayne is a character designed for the end of the game,
you can decide to or not to import her independing on if you like your 
team at the time. There is 30 items that will get them from the start 
to the end of the game, they all are inserted into shops so there is 
no need to mess around with the character control to get them into your
game. I made them with TOSC installed so some may not work if you do not
have it installed. They allhave custom descriptions and were made for 
the character that it says, but you can swap some of them around. None
of them are really very different but I think they add a bit to the 
game. This was designed to be played in multiplayer.

Instructions:
Put the 30 items and stores into the overides folder.
Put the characters in the characters folder.
Put the portraits into your portraits folder (if you have not got one
just put the portraits folder with the portraits in, into your main
Baldur's Gate Directory.
Have fun!!!

Note:
I based these characters on the Wheel of Time Series by Robert Jordan
these are great books, if you have not read them you should.


P.S
If you have any comments about this or anything on my site please 
e-mail me at:

chris_simpson1@btinternet.com


P.P.S
If you like these and think I should make more please e-mail me at the
above address because it makes the effort worth my while. If you don't
like it well that's your problem, I made it for myself and I thought
others might like it so I put it up on the web, it takes time and 
effort to do this kind of thing so stop being ungrateful. 

Thanks To:
TeamBg for making all of this possible, go to there site at:
www.bgrealms.com/teambg
Lady Nightshade, for the custom portraits, go to the portraits section
on the Teambg web site.
TeamBg's Message board people for helping a stupid Newbie.