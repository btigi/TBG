This is a A Aegis Fang, it is a warhammer +4 +2
electric damage. It can be used in melee or can be thrown. It returns 
to hand once thrown.

If you need any instructions on how to use this weapon go to the 
instructions page on my web site.

Simclass

If you want to use this or any other of the things on my web site for 
any other web sites can you please ask first, I will very likely 
say yes but they do take me time to make so I would to be asked first.
