This is Corvuus's Hate, a short sword +4 for use in Baldur's Gate 2. You will need Infinity Engine Explorer to import the tbg file. Here are the stats:

Short Sword +4, Corvuus's Hate

This short sword was first used by Corvuus, a mercenary assassin with a special dislike for mages. Corvuus was the best at what he did and therefore charged some very high prices. The jobs were always finished right, however. Corvuus received this sword as a +3 short sword after an argument with an employer over payment that ended in bloodshed. Soon, it became his favorite sword to use in his jobs and he used right up until his natural life ended.

Corvuus never actually died, however, but was imprisoned in his own sword after a failed assassination attempt on a very powerful mage called Nava. His hatred of mages became even more so after this, and this part of him also became part of the blade. Somehow Corvuus managed to put his feeling of hate into the blade, causing it to become a mage killer. The blade also glows red with hate.

STATISTICS:

Equipped Abilities:
 -2 Penalty to Intelligence
 User Silenced
 10% Bonus to Move Silently
Special Ability: Silence 15' radius three times per day
Combat Ability (each hit):50% chance that the target will be silenced for 1 turn with no saving throw
THAC0: +4 bonus
Damage: 1D8 +4
Damage type: piercing
Weight: 6
Speed Factor: 2
Proficiency Type: Short Sword
Type: 1-handed
Requires: 5 Strength
          5 Intelligence
Not Usable By:
 Druid
 Cleric
 Mage
 Good Aligned Characters


by GrimReaper
poof_3009@hotmail.com