I took this cool item from Icewind dale Heart of Winter and modified it for bg2 and Tob

These arrows are known less for their damaging power than they are for 
their annoying summoning power.  
Invented by a black-hearted gnome named Turbar Talinbar, 
the Goblin Arrows are commonly found in the quivers of mischievous halflings and elves.  
Several adventuring companies use the Goblin Arrows before launching any major attacks.
STATISTICS:Damage:  1D6 +1THAC0:  +1Damage Type:  Missile (Piercing)
Special:  On a successful hit, a goblin is summoned next to the target.
Weight:1 Launcher:  Bow
Not Usable By: Cleric Druid Mage

****ALWAYS BACK UP THE DIALOG.TLK FILE**** 
Using IAP Pro/Std to Import iap filesto the Overrides folder, which does everything for you. 
In Baldur.ini/Icewind.ini add the line "Cheats=1" to [Game Options]. 
Baldurs Gate2 Shadows of Amn and Throne of Bhall "Debug Mode=1" 
Once in the game press CTRL+TAB to get the console up.
In Bg2 and Tob Press ctrl spacebar 
Write CLUAConsole::CreateItem("ITEM_NAME"); 
The item should now be in your leaders inventory.

Tannariss@drkness.com
The Dark Realms 
http://www.drkness.com

For All the editors and answers to all your editing questions go to
Team Baldurs Gate
http://www.teambg.com 
Be shure to peruse the great forums. 
