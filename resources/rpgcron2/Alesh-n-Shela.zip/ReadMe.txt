This pack contains two swords, Alesh and Shela, to be used in an upcoming mod I am making. One does extra cold damage, while the other does extra fire damage. They're pretty fun to use together, just run the IAP, CLUA in the items NBhot and NBcold, and enjoy :)

If, for some reason, have to delete the files that were in the IAP, they are:

NBhot.itm
NBcold.itm

Created by Neeber.
krain@tx3.net