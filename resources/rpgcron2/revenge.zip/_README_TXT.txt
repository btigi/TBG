==================================================================================
Pack Name:  Revenge bringer
==================================================================================
Creator Name:  Mhoram with Exnem�s help
Creator Email:  aimainahikari@hotmail.com
Creator Web URL:  
==================================================================================
Compatible Games:
-----------------

 [ ] Baldur's Gate
 [ ] Baldur's Gate: Tales of the Sword Coast

 [x] Baldur's Gate II: Shadows of Amn
 [x] Baldur's Gate II: Throne of Bhaal

 [ ] Icewind Dale
 [ ] Icewind Dale: Heart of Winter
 [ ] Icewind Dale: Heart of Winter with Trials of the Luremaster

 [ ] Icewind Dale II

 [ ] Planescape: Torment

==================================================================================
Pack Contents/Description:
--------------------------

This is a +6 katana wich can slay an oponent with one only hit and allow you to cast 
cloack of fear and heal three times per day. 
It also have a custom bam from Exnem  (visit his page at 
www.3dconsortium.com/bgvault/index.htm if you want to find 
a lot of things for baldurs gate and remember to download his mod at teambg.com) 
and a large history (in spanish, sorry i �m not so good at english). 
If this sword is too similar to one halberd  (the most powerfull weapon for me) 
of the game well it�s my first item don�t be too severe with me. 

==================================================================================
SPECIAL INSTRUCTIONS:
---------------------
 only remember to visit www.3dconsortium.com/bgvault/index.htm and www.teambg.com


==================================================================================
HOW TO INSTALL:
---------------
An exception to the following information is if you use the new IAP-SFX maker
to make self installing IAP files (*.exe).

To insert this custom file or file pack into your game, you need to download,
install and use TeamBG's IEES (Infinity Engine Editor Standard). This program
contains the Infinty Add-on Patcher. This is used to import custom files (TBG or
IAP files) into your game.  This process is like UNZIPPING a ZIP file. It drops
all the files into the right locations for your game to use them and makes the
updates to your master text file for your game so that all the new items, spells,
etc. have their new names and descriptions.

To get IEES (which can be used to install any IAP/TBG files you find on the web)
goto TeamBG's web site with this URL to go directly to the IEES download:

http://www.teambg.com/iees.htm

Now depending upon how the creator made this pack, there may be special
instructions about what to do to activate or spawn the item, spell, creature, or 
whatever when you actually run your game.  See the special instructions section
above for this information.
==================================================================================
Visit the following sites to make your games more fun:
------------------------------------------------------
http://www.teambg.com/  (game customizing programs/editors)
http://www.teambg.org/  (game MOD/add-ons/total conversion news)
http://www.dsotsc.com/  (Dark Side of the Sword Coast unofficial BG/TotSC add-on)


