==================================================================================
Kit Name:  Crusader (Paladin Kit)
==================================================================================
Creator Name:  Hansoo
Creator Email:  hansoo@one.lv
==================================================================================

Installation.

1. Unzip files in your BG2 Override folder.
2. Use KitEditor to import files from crusader.kit into your Override folde.