Just unzip to override folder.
In Baldur.ini/Icewind.ini add the line "Debug Mode=1" to [Program Options]. 
Once in the game press CTRL+TAB to get the console up. 
Write CLUAConsole:CreateItem("ITEM_NAME"); 
The item should now be n your leaders inventory. 


NP: I want to modify this game.. but i need help.. so if u able to modify this game please contact me at xman@ekilat.com   :)  :P