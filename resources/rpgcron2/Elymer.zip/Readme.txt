==================================================================================
Pack Name: Elymer
==================================================================================
Creator Name: Malnefein 
Creator Email:  Narkagin@hotmail.com
Creator Web URL:  None
==================================================================================
Compatible Games:
-----------------

 [ ] Baldur's Gate
 [ ] Baldur's Gate: Tales of the Sword Coast

 [ ] Baldur's Gate II: Shadows of Amn
 [x] Baldur's Gate II: Throne of Bhaal

 [ ] Icewind Dale
 [ ] Icewind Dale: Heart of Winter
 [ ] Icewind Dale: Heart of Winter with Trials of the Luremaster

 [ ] Planescape: Torment

==================================================================================
Pack Contents/Description:
--------------------------
This is a +1 mace that strikes as a +5 weapon. Rather useless against "normal" enemies (let's say, "human" ones), but insamely powerful (in my opinion) against outerplanar beings. Each type of outerplanar creatures has a chance to be killed outright, depending on their power, from the little annoying mephit (yes, mephits are instantly destroyed without save, so get this mace now all you mephit haters ;-) ) to the all-powerful solars (if you ever kill one instantly in one hit, buy a loto ticket, you'll win!). While weilding the mace, your character is also protected against these creatures ar per under the effect of a Protection from Evil spell (i.e. -2 to extraplanar creatures and +2 to your save vs. their attacks). Add it to a store, a creature, wathever... The name's m_blun01.

If you have any coments, suggestions or critics to tell me, please E-mail them to 
Narkagin@hotmail.com

==================================================================================
SPECIAL INSTRUCTIONS:
---------------------


==================================================================================
HOW TO INSTALL:
---------------
To insert this custom file or file pack into your game, you need to download,
install and use TeamBG's IEES (Infinity Engine Editor Standard). This program
contains the Infinty Add-on Patcher. This is used to import custom files (TBG or
IAP files) into your game.  This process is like UNZIPPING a ZIP file. It drops
all the files into the right locations for your game to use them and makes the
updates to your master text file for your game so that all the new items, spells,
etc. have their new names and descriptions.

To get IEES (which can be used to install any IAP/TBG files you find on the web)
goto TeamBG's web site with this URL to go directly to the IEES download:

http://www.teambg.com/iees.htm

Now depending upon how the creator made this pack, there may be special
instructions about what to do to activate or spawn the item, spell, creature, or 
whatever when you actually run your game.  See the special instructions section
above for this information.
==================================================================================
Visit the following sites to make your games more fun:
------------------------------------------------------
http://www.teambg.com/  (game customizing programs/editors)
http://www.teambg.org/  (game MOD/add-ons/total conversion news)
http://www.dsotsc.com/  (Dark Side of the Sword Coast unofficial BG/TotSC add-on)

