March 1, 2002     "Orcist, The Goblin Cleaver" made by Greysteil

The file GOB2BG.ITM is the sword "Ocrist,The Goblin Cleaver" found & used by Thorin Oakenshield in J.R.R Tolkien's The Hobbit.

Just import the file GOB2BG.TBG, and you will be able to use it in the game.  If you don't already have it, you can get the proper tool for importing from http://www.teambg.com.

Any questions, complaints,comments, please email me @

Greysteil@thesquirespipe.com

