March 1, 2002     "Sting, the Spider Stinger" made by Greystiel

The file sting1.itm is the sword "Sting, the Spider Stinger" found & used by Bilbo Baggins in J.R.R Tolkien's The Hobbit.

Just import the file STING.TBG, and you will be able to use it in the game.  If you don't already have it, you can get the proper tool for importing from http://www.teambg.com.

Enjoy! 

Any questions, comments, complaints, ect. please email me @

Greysteil@thesquirespipe.com

