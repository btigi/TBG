The Warblade, is one of the three elfblades of Myth Drannor. Ary'Velahr'Kerym gives +4 to thac0 and damage, +2 bonus
to AC, as do the other two elfblades. Additionally, the wielder raise his strength to 19 3x a day, can detect evil
 at will, and raise a blade barrier around himself. (be careful of the blade barrier, as it does not distinguish
between friend or foe and will damage anyone too close to the wielder.

To get this weapon into your game you need to visit Teambg's website and download a few of their awesome editing
tools, (VB6, and one of the editors with Item Maker.. such as IEEP or IEES) then use the Item maker's "import tbg"
option choose the folder warblade is in and the program will convert the item from .tbg to .item  make sure to
save it into the Override folder of your BGII menu.

Enjoy!,

Elurin.