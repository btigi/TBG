At first glance, this oversized Two-Handed sword appears to be crudely made. It almost appears that the sword had been squashed by a heavy fast moving object, and its edges are quite ragged. Upon closer examination, it turns out the the blade is actually the HackMaster, the "brother" sword of Lilarcor. The blade is incredibly sharp, surpassing the edges of all other enchanted swords. The amazing edge of this weapon does have its drawbacks however. Since it has no hilt, there is nothing to protect the bearers hands from occasional slips. For this reason, the wielder is always below his maximum possible health due to the numerous accidental cuts and nicks the blade inflicts. It is because of this sharpness that the HackMaster is hard to wield in battle, since the bearer must avoid being hit with his own sword as well as by the enemy. There is also the chance that a very unlucky bearer may inflict a killing blow upon himself, a truly unfortunate feature of this blade. This sharpness of the sword is therefore a blessing and a curse and few keep the HackMaster for long, and are disappointed at the price it fetches. It would be hung in a museum somewhere if it weren't for the fact that it slices clean through most mountings. No one knows where it came from, although some say that it was a man named Dave, a Knight of the Dinner Table, who first bore this fabulous, if painful, weapon. Some say that he parted with his beloved sword only after losing so many fingers to it that he could no longer hold it. From there it has apparently slashed its way through dozens of other owners to find its way to your scabbed hands.

STATISTICS:

Equipped Abilities:
 -2 to Dexterity (due to trying to avoid being cut by your own blade)
 -15 HP while equipped (from the cuts and scratches incurred while handling the blade)

Combat Abilities:
 5% of a Vorpal Hit ON THE WIELDER (save vs. Death/Poison to survive)

Damage:  1D10 +12
THAC0: +12 bonus
Damage type:  slashing
Weight: 10
Speed Factor: 8
Proficiency Type: Two Handed sword
Type:  2-handed
Requires: 14 Strength
Not Usable By:
 Druid
 Cleric
 Mage 
 Thief
 persons wishing to keep their fingers attached

This custom item was made using Infinity Engine Editor Pro (IEEP) from TeamBG.net. You will need to have this program installed in order to import the .TBG file (Infinity Add-on Patcher part). It will install the item automatically. Please note that Throne of Bhaal must be installed for this to work. Enjoy!!

Gaiseric the Vandal