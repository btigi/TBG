To install, just use IEEP or IEES to import the iap file. Unfortunately, there is no way to add characters into an already begun game so you have to start a new game. If you want the upgraded sword in your current game the item code is sw1h99. Just use CLUAConsole or ShadowKeeper to import it.

The Celestial Jewel can be found on the Sahuagin king's body. To kill him you will need to side with the Sahuagin prince. I did this because if you side with the king you get the Gauntlets of Crushing but nothing for siding with the prince, so this offsets that.

GrimReaper
poof_3009@hotmail.com