
==================================================================================
Pack Name:  Fun Staff
==================================================================================
Creator Name:  Jan Jansen
Creator Email:  krain@tx3.com
==================================================================================
COMPATIBLE GAMES:
-----------------

 [ ] Baldur's Gate
 [ ] Baldur's Gate: Tales of the Sword Coast

 [x] Baldur's Gate II: Shadows of Amn
 [?] Baldur's Gate II: Throne of Bhaal

 [ ] Icewind Dale
 [ ] Icewind Dale: Heart of Winter
 [ ] Icewind Dale: Heart of Winter with Trials of the Luremaster

 [ ] Planescape: Torment


==================================================================================
PACK CONTENTS/DESCRIPTION:
--------------------------

This staff has a chance to turn the target into a chicken and/or change the target's gender

==================================================================================
SPECIAL INSTRUCTIONS:
---------------------

Just CLUA in the "JJfunstf" item and have a good time

==================================================================================
HOW TO INSTALL:
---------------

Double click the tbg file.