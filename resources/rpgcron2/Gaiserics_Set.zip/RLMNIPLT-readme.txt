RILMANI PLATE
This brightly colored Plate Mail was created for the Tiefling Rilmani Fighters of Sigil. This powerful plate is known to provide extensive and powerful protections on the wearer. In addition, the enchantments of this plate mail will alter the wearer's appearance, leading some to believe that those who where it may actually be a Rilmani from Sigil. It might not be a good idea to wear it in the presence of Tieflings or other Planar beings, since their reaction to it is not easily predicted. How it came to be in your possesion is not known, although it could have come from Ferrumach Rilmani when he was killed by intruders into the Watcher's Keep prison.

STATISTICS:
   +100% resistance to all lightning and electrical attacks
 +50% resistance to acid
 +35% resistance to magic
 +1 to all saves
 +2 attacks per round
 +1 to Constitution
 Cast Improved Invisibilty once per day
 Regenerate 3 HP/round
 +2 to speed rate
 Immunity to charm, hold, confusion, stun, and psionic attacks
  Immunity to Backstab
 
Armor Class: -1
Weight: 20
Requires: 15 Strength
Not Usable By:
 Bard
 Druid
 Mage
 Thief


This custom item was made using Infinity Engine Editor Pro (IEEP) from TeamBG.net. You will need to have this program installed in order to import the .TBG file. It will install the item automatically. Please note that Throne of Bhaal must be installed for this to work. Enjoy!!
