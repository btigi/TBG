Blackmantle Plate +6

This black plate mail armor has more often been spoken of than actually seen. The Blackmantle plate was developed by a group of powerful liches for the mercenaries who fought on their behalf during a struggle for control of a dark kingdom against a cabal of master wraiths. These mercenaries became known as the Blackmantles, in referce to this dark armor. This plate is so black it almost seems to absorb light, and exhibits no glimmer as ordinary armor would. The Blackmantle plate was designed for combat against powerful undead, and its powers protect the wearer against almost all mind influence spells. Legend has it that is worked too well for the mercenaries, since after destroying the wraiths they turned on their lich masters and seized control for themselves. Only evil characters may wear this armor, since the enchantments that give it its power would turn a man's soul as black as coal. Those surviving its evil should be warned that it will serve to attract powerful evil beings who will seek to use it for themselves. Despite its rarity, some sets are known to exist outside of the unnamed dark kingdom.

STATISTICS:

Equipped Abilities:
Immunity to fear, hold, stun, charm, and confusion while equipped.
Immunity to level drain

Armor Class: -5
Weight: 50
Requires: 15 Strength
Not Usable By:
 Bard
 Druid
 Mage
 Thief
 Non-humans or half-orcs
 Good characters

This custom item was made using Infinity Engine Editor Pro (IEEP) from TeamBG.net. You will need to have this program installed in order to import the .TBG file. It will install the item automatically. Please note that Throne of Bhaal must be installed for this to work. Enjoy!!
