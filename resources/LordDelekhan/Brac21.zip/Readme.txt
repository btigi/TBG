This is a simple set of bracers that should have been in the game


LordDelekhan

Bracers of Defense A.C. 0

Armor Class: 0

***NOTE***
This item comes with its own graphic file, copy the bam file into your override folder