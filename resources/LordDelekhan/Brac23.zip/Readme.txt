This is a set of bracers aimed at the pure magic user for when the magic runs out



LordDelekhan

Otrad Atwah: 'Gloves of the Magi'

Armor Class: 0
Special: Increased Attacks
Special: Increased Saving Throws
Usable Only By:
Mage (Single Class Only)

***NOTE***
This item comes with its own graphic file, copy the bam file into your override folder