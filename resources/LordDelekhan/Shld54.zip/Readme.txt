This is one of a set of shields I found in an old p&p game.  
I couldn't resist bringing them into the game.


LordDelekhan


Large shield +2, +6 vs. missiles:  'The Wall'


***NOTE***
This item has its own graphic file, copy the bam file into your override folder
