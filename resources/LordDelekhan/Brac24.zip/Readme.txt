This is a set of bracers aimed at the pure lovers of the forests



LordDelekhan

Gift of the Woods

Armor Class: 0
Special: Increased Attacks
Special: Increased Resistance to Petrification
Usable Only By:
Druids (Single Class Only)
Rangers(Single Class Only)

***NOTE***
This item comes with its own graphic file, copy the bam file into your override folder