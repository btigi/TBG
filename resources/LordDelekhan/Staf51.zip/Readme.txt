This is the third and final staff of this set, again made with a character for the page in mind.


LordDelekhan

Staff of Alchemy
Damage:  1D6 + 2
THACO:  +2
Special: 
Creates Potions:
    Antidote
    Fire Breathing
    Insulation
Only usable by:
Mage (single, dual, & multi-class)
Neutral-aligned characters 

***NOTE***
This item has its own graphic file, copy the bam file into your override folder
