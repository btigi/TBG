This is part of a set of items created for the latest character I have
brought into the game.  With the exception of the arrows each of these
is made with a paladin alone in mind.


LordDelekhan

Helm of the Holy Guard. 
Armor Class Bonus: None
Special:  Protects Against Critical Hits
Special:  Protects Against Mental Attacks
Usable Only By:
Paladin 


***NOTE***
This item has its own graphic file, copy the bam file into your override folder
