This item was created for a truely evil mage I added to the page.


LordDelekhan

Ethric
Damage:  2D8 +1
THACO:  +1
Damage type:  piercing
Special:  8 damage inflicted upon the wielder upon every successful hit
Special: Immunity to Non-Magical Weapons
Armor Class: -13 Penalty
Only usable by:
Mage (single, dual, & multi-class)
Evil-aligned character


***NOTE***
This item has its own graphic file, copy the bam file into your override folder
