This is part of a set of items created for the latest character I have
brought into the game.  With the exception of the arrows each of these
is made with a paladin alone in mind.


LordDelekhan

Signet Ring of the Sukien.  
Armor Class:  +1 bonus
Saving Throws:  +2 bonus
Special: Gain Protection from Petrification
Usable Only by:
 Paladin 


***NOTE***
This item has its own graphic file, copy the bam file into your override folder
