This is a fairly strong axe, I have always been a fan of the minotaur and wanted to bring
even just a piece of their lore into the game.


LordDelekhan

Minotaur Axe
Damage:  4D4 +3
THACO:  +3 bonus

***NOTE***
This item has its own graphic file, copy the bam file into your override folder
