This is part of a set of items created for the latest character I have
brought into the game.  With the exception of the arrows each of these
is made with a paladin alone in mind.


LordDelekhan

Arrow of Striking
Damage:  1D6 +3
Special:  2D3 Magical Damage upon Impact


***NOTE***
This item has its own graphic file, copy the bam file into your override folder
