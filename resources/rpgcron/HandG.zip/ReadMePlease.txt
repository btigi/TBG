*******************************************************************************************
*                                                                                         *
* IMPORTANT: You must have Throne of Bhaal installed to use the second Scimitar Greed +4. *
*                                                                                         *
*******************************************************************************************

You should see this file:

HandG.iap

Now extract it and then import it using IAAP(Infinity Add-On Patcher) which is part of 
IEEP(Infinity Engine Editor Pro).

If you don't have the Cheat mode enabled then do this first:

Go into Baldur.ini in your BG2 folder and type this under Game Options: Debug Mode=1.

Now start your game and hit CTRL and SPACEBAR at the same time. Then type 
CLUAConsole:CreateItem("xxxxxxxx"), where "xxxxxxxx" would be "Hatred01".
Do the same thing to import the other sword, this time type "Greed01".

*******************************************************************************************

** How to Test the item **

-Start a tutorial with a warrior who has the Scimitar proficiency and isn't of Good alignment.

-Press 'CTRL + Q' when your mouse is over Belt.

-Now walk up to him and smack him around a bit. You can dual-wield aswell.

-Don't be surprised if a creature pops up, it will be your ally unless you damage it.

-Now if you haven't already done so, identify the swords and learn about their bonuses and
penalties.

*******************************************************************************************

Feel free to distribute the zip file, but without any changes to it.

To get IEEP go to:  www.teambg.com

My email address:   rashamon8080@hotmail.com

********
Rashamon
