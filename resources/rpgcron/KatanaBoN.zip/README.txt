
==================================================================================
Pack Name: Blade of the Night
==================================================================================
Creator Name: Kai  
Creator Email: weskerr@ignmail.com
Creator Web URL:  
==================================================================================
Compatible Games:
-----------------

 [ ] Baldur's Gate
 [ ] Baldur's Gate: Tales of the Sword Coast

 [x] Baldur's Gate II: Shadows of Amn
 [x] Baldur's Gate II: Throne of Bhaal

 [ ] Icewind Dale
 [ ] Icewind Dale: Heart of Winter
 [ ] Icewind Dale: Heart of Winter with Trials of the Luremaster

 [ ] Planescape: Torment

==================================================================================
Pack Contents/Description:
--------------------------

katana stats:
1D10+4 
THAC0+4 bonus
-1 to strenght
-1 to constitution
+1 to dexterity
regenerates 1 hp/6secs
immunity to poison
+45% to hide in shadows/walk
+35% open locks/set snares/detect traps
+15% detect illusion
on each hit the target must save vs. spells or
receive additional 2 points of fire+acid+cold+electric damage

only usable by thieves.

this katana is made by me,Kai,story description and idea not by me but by
someone on the gamebanshee boards (sorry,i cant remember their name)

you can buy the katana from one of the bonus cd shops in the cc,the bonus cd shops are also
in this pack.

==================================================================================
SPECIAL INSTRUCTIONS:
---------------------
you will need ieep or iees to get the katana to work.(see below)
==================================================================================
HOW TO INSTALL:
---------------
To insert this custom file or file pack into your game, you need to download,
install and use TeamBG's IEES (Infinity Editor Standard). This program contains
the Infinty Add-on Patcher. This is used to import custom files (TBG or IAP files)
into your game.  This process is like UNZIPPING a ZIP file. It drops all the files
into the right locations for your game to use them and makes the updates to your
master text file for your game so that all the new items, spells, etc. have their
new names and descriptions.

To get IEES (which can be used to install any IAP/TBG files you find on the web)
goto TeamBG's web site with this URL to go directly to the IEES download:

http://www.teambg.com/iees.htm

Now depending upon how the creator made this pack, there may be special
instructions about what to do to activate or spawn the item, spell, creature, or 
whatever when you actually run your game.  See the special instructions section
above for this information.
==================================================================================
Visit the following sites to make your games more fun:
------------------------------------------------------
http://www.teambg.com/  (game customizing programs/editors)
http://www.teambg.org/  (game MOD/add-ons/total conversion news)
http://www.dsotsc.com/  (Dark Side of the Sword Coast unofficial BG/TotSC add-on)
