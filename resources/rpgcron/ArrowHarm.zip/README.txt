
==================================================================================
Pack Name:Arrow of Dark Harm
==================================================================================
Creator Name: Mortis  
Creator Email: The_corrupt@hotmail.com 
Creator Web URL:http://www.angelfire.com/darkside/necropolis/
==================================================================================
Compatible Games:
-----------------

 [ ] Baldur's Gate
 [ ] Baldur's Gate: Tales of the Sword Coast

 [X] Baldur's Gate II: Shadows of Amn
 [X] Baldur's Gate II: Throne of Bhaal
 [x] Baldur's Gate II: The Darkest Day (http://www.teambg.net/tdd/)

 [ ] Icewind Dale
 [ ] Icewind Dale: Heart of Winter
 [ ] Icewind Dale: Heart of Winter with Trials of the Luremaster

 [ ] Planescape: Torment

==================================================================================
Pack Contents/Description:
--------------------------
1- A new very powerful arrow that does harm on a hit (reduces target to 4 hit points)
it also breaks any shield or item in the left hand.
ontop of this it embeds into the victim and renders them immune to healing till removed
removal is via dialog (and inflicts 2d6 damage) 

WARNING this arrow is ment as a one off item 
(equipping 5000 of them will totaly ruin your gameplay)

HOW TO INSTALL:
---------------
WARNING THIS PACK REPLACES ITEMDIAL.2DA 
(back it up first if in doubt)

run exe  (AFTER unzipping it)
start game and Clau code in the item "FCARHARM"
shoot some-one in your party to fully see the effects 
(this item is not realy ment for players, i plan to equip a cre assassin with it,
but i made it as a pack cause a lot o' ppl asked me to.)

==================================================================================
Thanks to KenTeamBG for great talk on the process's i used to make this.
