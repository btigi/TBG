==================================================================================
Item Name:  Angey's Revenge
==================================================================================
Creator Name:  Hansoo
Creator Email:  hansoo@one.lv
==================================================================================

Installation

1. Unzip file SwKat01.tbg into your BG2 Override folder.
2. Import it with Infinity Engine Editor into Override folder.
3. Use CLUAConsole:CreateItem("SwKat01");