==================================================================================
Pack Name:  Dark Fury
==================================================================================
Creator Name:  Dark Avatar 199
Creator Email:  NA - Stands for Not Avaliable.
Creator Web URL:  NA - Stands for Not Avaliable. GEEZ IM SAYING IT AGAIN!
==================================================================================
Compatible Games:
-----------------

 [ ] Baldur's Gate
 [ ] Baldur's Gate: Tales of the Sword Coast

 [x] Baldur's Gate II: Shadows of Amn
 [x] Baldur's Gate II: Throne of Bhaal

 [ ] Icewind Dale
 [ ] Icewind Dale: Heart of Winter
 [ ] Icewind Dale: Heart of Winter with Trials of the Luremaster

 [ ] Icewind Dale II

 [ ] Planescape: Torment

==================================================================================
Pack Contents/Description:
--------------------------
This pack includes Blkatan.itm and Blkatan.bam in a iap file. Both are of my own work and can be used in SoA or SoA
with ToB. I would like to give great thanks to Ken and all of those who made those great programs of the infinty engine!
Sorry I don't have an Email address. But it is only for awhile until I set up my verizon email account.
==================================================================================
SPECIAL INSTRUCTIONS:
---------------------
Install as below, You can get these items by two ways, Using the cheat console by activating it in your baldur.ini in the
Baldur's Gate2 SoA main folder [Game Options] type Cheats=1 and save. once ingame press ctrl+tab to make the console
come up and type CLUAConsole:CreateItem lets just say ("Blkatan.itm") or importing them in using Shadow Keeper.
==================================================================================
HOW TO INSTALL:
---------------
An exception to the following information is if you use the new IAP-SFX maker
to make self installing IAP files (*.exe).

To insert this custom file or file pack into your game, you need to download,
install and use TeamBG's IEES (Infinity Engine Editor Standard). This program
contains the Infinty Add-on Patcher. This is used to import custom files (TBG or
IAP files) into your game.  This process is like UNZIPPING a ZIP file. It drops
all the files into the right locations for your game to use them and makes the
updates to your master text file for your game so that all the new items, spells,
etc. have their new names and descriptions.

To get IEES (which can be used to install any IAP/TBG files you find on the web)
goto TeamBG's web site with this URL to go directly to the IEES download:

http://www.teambg.com/iees.htm

Now depending upon how the creator made this pack, there may be special
instructions about what to do to activate or spawn the item, spell, creature, or 
whatever when you actually run your game.  See the special instructions section
above for this information.
==================================================================================
Visit the following sites to make your games more fun:
------------------------------------------------------
http://www.teambg.com/  (game customizing programs/editors)
http://www.teambg.org/  (game MOD/add-ons/total conversion news)
http://www.dsotsc.com/  (Dark Side of the Sword Coast unofficial BG/TotSC add-on)


