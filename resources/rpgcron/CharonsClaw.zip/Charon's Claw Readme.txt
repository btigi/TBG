Charon's Claw

This sword and gauntlet combination is known as Charon's Claw, and it is very useful against wizards. The gauntlet grants the wearer spell turning on all spells up to the 6th level, however, 7th and beyond still affect you normally. Charon's Sword has a chance to cause Miscast Magic and to disease the target on a successful hit.

To get this weapon into your game you need to visit Teambg's website and download a few of their helpful editing
tools, (VB6, Infinity Engine Editor Pro or some such) then use the Item maker's Import .TBG option, choose the folder Charon's Claw is saved in , and the program will convert the item from .tbg to .item. Make sure the item is saved in the override folder in your BGII folder. To import, after you have your cheats enabled, and the console up in game, type:

CLUAConsole:CreateItem("charswd"), then after getting that item:
CLUAConsole:CreateItem("charclaw") and you will be set.

Any questions, comments, or suggestions? Send em to me at: detheone@hotmail.com

Dethe One