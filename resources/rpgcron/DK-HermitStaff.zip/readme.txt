Use teambg infinity Editor to import .iap file
The new item is called hstaff and is located in one of the tents in Trademeet