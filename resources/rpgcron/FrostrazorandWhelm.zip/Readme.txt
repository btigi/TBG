Here are two weapons inspired by The Berserk Seraph, who suggested that these are to be considered a set along with
Wave and Blackrazor, which can be found in SoA normally. Seraph mentioned that this set is taken from an old AD@D
sourcebook.

The items (and needed .spl files) are in an .iap file (properly tbg-ed ;) ), and installs into the override 
directory of your BGII game.

In order to use install this .iap into your game, you will need to visit Teambg (www.teambg.com) and download some
needed programs:
      1. IEES or IEEP (Infinity Engine Editor Pro or Standard)
      2. VB6 (which contains data needed to run the editor)

After installing IEE, Start it up, making sure to select BGII from the game choice menu at the top.
Click on "Inifinty Addon Patcher", then select "Import IAP/TBG".

You will need to have your Cheat menu activated to get the items into the game. Open up your BGII directory and
look for a file name baldur (its icon is a text file with a yellow gear on it), this is your config. settings file.
Open it up and write a new line in under Program Options: "Debug Mode=1" and save the document. Now when you start
your game, hit ctrl+space. A line will open up at the bottom write in "CLUAConsole:CreateItem("xxxx") xxxx being
the name of your custom file, for example (CLUAConsole:CreateItem("sw1h01")

Note: there are two versions of Whelm, Whelm01 is +4 and useable by all races. Whelm01D is +5 and useable only by
dwarves. The original item was to be +5 in the hands of a dwarf, and +3 to all others. So you can take yer pick :)

I cannot assure with 100% certainty that any of these files will not damage your computer or any of its
components (what in life is 100% sure?). Having said that, *I* trust 100% that the method is sound, the
programs by TeamBG having been used by many to add custom items, spells and such into their game.

Many thanks to TeamBG, without whom none of this would have been possible.


Enjoy, 

Elurin.