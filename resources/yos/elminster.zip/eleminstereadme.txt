This is Elminster the Mage, right now he is cursed by the turn sex curse 
but in time it might wear off. To use him just put him into the characters section
and start a new game. CLick import and then click Elminster. If elminster dosen't show up
you have to rename him something shorter. 
It was made by  david at yos@gis.net
