Here is a custom character the Zombie. He is very strong but is stupid, foolish and clumsy. 
Put the .chr and the .bio into the character section. Put the other .zip character into the 
portratis. All the rest go into the overide section.
Any questions or coments email me at yos@gis.net
 