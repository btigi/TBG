This is a very cool Genie Character, he is a priest with many spells. When he is uncounses he 
dissapares so dont worry when he vanashies!
It was made by  david at yos@gis.net
