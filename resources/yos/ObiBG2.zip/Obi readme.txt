
The Obi Wan Kenobi SPELL for bg2
level 9 wizard spell

by Methuselahn
2-25-01

  	Obi is partially smart.  Upon summoning he will sense the alignment of the protagonist and if he/she isn't of a Good alignment, he will leave the party.  Obi is considered a thief/mage.  He will cast spells that affect the mind of his enemies, making them confused, feebleminded, etc.  Obi also has a few damaging spells.  If he sees an enemy whos level is greater than 11, he will 'force push' them away or throw thermal detonators at them.  When there are no enemies about, he will search for traps and follow the protagonist.  
OBI WAN KENOBI MADE FOR LEGIT PLAY!  

**** Use the "Infinity Engine Add-On Patcher" located in IEEP program by TL. ****
**** This program and other awesome editors can be found at www.teambg.com.  ****
  
Import this iap file and put the  portrait in your portraits folder (had problems with the .iap maker for some reason)

The vital clua command (case sensative) is:
where n=number of scrolls to make
CLUAConsole:CreateItem("obiscrl",n)

if you have any problems or suggestions, drop me a line at azerradi@hotmail.com

The following files will be added to the correct folders...
obis.bmp
obi.bcs
obi.cre
spobi.eff
exting.wav
ignite.wav
swing.wav
swing2.wav
Obi readme.txt
obipush.tbg		(.itm)
obiring.tbg		(.itm)
obisabe.tbg		(.itm)
obiscrl.tbg		(.itm)
obisumm-s.tbg		(.spl)
obitalk-D.tbg		(.dlg)
binocs.tbg		(.itm)
thermal.tbg		(.itm)

Have Fun!

