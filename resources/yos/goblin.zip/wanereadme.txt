This is a very cool HobGoblin Character, he is a Wizard Slayer. Put his .cre and .bio into the character section and then start a new game
Import Goblin and Enjoy!
It was made by  david at yos@gis.net
