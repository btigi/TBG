
The Darth Maul SPELL for bg2

by Methuselahn
2-22-01

  	Maul is partially smart.  Upon summoning he will sense the alignment of the protagonist and if he/she isn't of an Evil alignment, Maul will leave the party.  Maul is considered a thief/mage.  He will cast spells that affect the mind of his enemies, making them confused, feebleminded, etc.  Maul also has a few damaging spells and spells that remove magical defences.  If he sees an enemy whos level is greater than 11, he will 'force push' them away or throw thermal detonators at them.  When there are no enemies about, he will search for traps and follow the protagonist.  DARTH MAUL IS MADE FOR LEGIT PLAY!  

****Use the "Infinity Engine Add-On Patcher" located in IEEP program by TL.****
  
import this iap file and put the 2 portraits in your portraits folder (had problems with the .iap maker for some reason)

The vital clua command (case sensative) is:
where n=number of scrolls to make
CLUAConsole:CreateItem("maulscrl",n)

if you have any problems or suggestions, drop me a line at azerradi@hotmail.com

The following files will be added to the correct folders...
dmauls.bmp
dmaull.bmp
dmaul.bcs
dmaul.cre
spmaul.eff
exting.wav
ignite.wav
maulfear.wav
swing.wav
swing2.wav
Maul readme.txt
maulpush.tbg		(.itm)
maulring.tbg		(.itm)
maulsabe.tbg		(.itm)
maulscrl.tbg		(.itm)
maulsumm-s.tbg		(.spl)
maultalk-D.tbg		(.dlg)
binocs.tbg		(.itm)
thermal.tbg		(.itm)

Have Fun!

